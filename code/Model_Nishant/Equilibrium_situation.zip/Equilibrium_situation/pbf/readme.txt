Here we see how the various densities change for a fixed by p/f ratio but varying p and f. The calculations are done for 3 different ratios: 10^3, 10^4 and 10^5 which are stored in 3 folders.

We have 1 plot, f_variation.m where we plot the change in fractions as a funciton of p.
The other plots are the time evoultion of fractions for different p values. The p values used are from: 0.01 to 0.2 in steps of 0.01. (Please the name of the image)

0.01- p0point01.m
0.02- p0point02.m
0.03 - p0point03.m
0.04- p0point04.m
0.05- p0point05.m
0.06- p0point06.m
0.07- p0point07.m
0.08- p0point08.m
0.09- p0point09.m
0.1- p0point1.m
0.11- p0point11.m
0.12- p0point12.m
0.13- p0point13.m
0.14- p0point14.m
0.15- p0point15.m
0.16- p0point16.m
0.17- p0point17.m
0.18- p0point18.m
0.19- p0point19.m
0.2- p0point2.m


pbf_data.txt store the info regarding various distributions for different p/f ratios.