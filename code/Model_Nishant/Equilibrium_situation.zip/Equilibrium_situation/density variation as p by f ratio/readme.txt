Here, we see that for a fixed p, density distribution does not change as we change the f/p ratio 

We vary f/p from 100-100000
N=256
p=0.1 and 0.17