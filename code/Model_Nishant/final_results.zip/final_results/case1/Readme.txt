(1) Data:
Grid Size= 200
p=0.001
p/f=10
Number of Iterations=5000


(2)Image:
case1_size_500_p_0point001_ratio_10.png

Grid Size= 500
p=0.001
p/f=10
Number of Iterations=10000
