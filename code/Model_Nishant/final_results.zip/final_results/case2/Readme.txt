(1) Data:
Grid Size= 200
p=0.1
p/f=1000
Number of Iterations=5000


(2)Image:
case2_size500_1000iter_p_0point1_ratio_1000.png

Grid Size= 500
p=0.1
p/f=1000
Number of Iterations=1000
