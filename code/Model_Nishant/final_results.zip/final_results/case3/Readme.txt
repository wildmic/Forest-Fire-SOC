(1) Data: data_0point1_10power1_1000_200
Grid Size= 200
p=0.1
p/f=10
Number of Iterations=1000


(2)Image:
case3_size500_1000iter_p_0point1_ratio_10.png

Grid Size= 500
p=0.1
p/f=10
Number of Iterations=1000
