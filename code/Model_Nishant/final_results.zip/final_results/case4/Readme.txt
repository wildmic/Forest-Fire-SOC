(1) Data:
Grid Size= 200
p=0.001
p/f=1000
Number of Iterations=5000

(2)Image:
case4_size50_10000iter_p_0point001_ratio_1000.png

Grid Size= 50
p=0.001
p/f=1000
Number of Iterations=10000

(3)Image:
case4_size500_10000iter_p_0point001_ratio_1000.png

Grid Size= 500
p=0.001
p/f=1000
Number of Iterations=10000


(3)Image:
case4_size500_10000iter_p_0point01_ratio_1000.png

Grid Size= 500
p=0.01
p/f=1000
Number of Iterations=10000
case4_size500_10000iter_p_0point01_ratio_1000