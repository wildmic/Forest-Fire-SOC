We plot the Log (cluster radius) vs Log (number of trees in a cluster) and Log (cluster radius distribution) vs Log (number of trees in a cluster). 
The 3 folders are for different grid sizes.
p=0.17,
p/f=10000,
all the systems were evolved upto 1000 steps. 

Stored Data:
Forest_grid- it stores the states of all the cells in the grid

s- it stores the information on various cluster sizes.

Number_distribution- it stores the number of clusters for all the cluster sizes.

Radius_distribution- it stores the information of cluster radii for all the cluster siizes.