Here we see how the various densities change for a fixed by p/f ratio but different p and f. The calculations are done for 3 different ratios: 10^2, 10^3 and 10^4 which are stored in 3 folders.

We have 1 plot, f_variation.m where we plot the change in fractions as a funciton of p.
The plots show the time evoultion of fractions for different p values. The p values used are from: 0.001 to 0..005 in steps of 0.01. (Please the name of the image)
