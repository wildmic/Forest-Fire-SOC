Here we see how the various densities change for a fixed by p/f ratio but varying p and f. The calculations are done for 3 different ratios: 10^3, 10^4 and 10^5 which are stored in 3 folders.

pbf_data.txt store the info regarding various distributions for different p/f ratios.