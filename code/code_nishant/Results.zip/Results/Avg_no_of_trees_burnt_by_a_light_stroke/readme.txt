We want to see the variation of number of trees burnt per fire stroke as a function of changing ratio, p by f.

We do it for 2 different values of p
p=0.1 [Folder "p0point1"]
p=0.17 [Folder "p0point17"]

In folder "p0point1", we store the info for 2 different number of iterations: 750 and 1000.

The basic procedure involves counting the number of burnt trees and number of lightening strokes after the initial transient period.
For 750 iterations, we count after 350 iterations.
For 1000 iterations, we count after 500 iterations.

In folder "p0point17", we store the info for 1000 iterations and 2000 iterations. In both the cases, we consider transient period upto first 500 iterations.


In all the folders,
lightcounter.m- it stores the number of lighening strokes for various p/f ratios

burntcounter.m- it stores the number of burnt trees for various p/f ratios

p_by_f.m- it stores the various p/f ratios used. we go from 1000-100000 in 50 steps.