We verify that the final density of trees, empty sites and fires is independent of initial conditions.
We vary the probability of growing the trees in the initial grid.
The varying probability is stored in probty.m
The corresponding densities of trees, fires and empty sites are stored in trees.m, fires.m and empty.m

p/f=10^4
N=256
p=0.17
probability varies b/w: 0.1-0.9